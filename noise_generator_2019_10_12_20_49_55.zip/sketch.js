let theNoise; //noise object
let playButton, stopButton, chooseNoise, setVolume, toggleOnOff; //dom objects


function setup() {
  //createCanvas(400, 400);
  theNoise = new p5.Noise();
  theNoise.amp(0);
    
  

  //create buttons
  toggleOnOff = createButton("on/off");
  toggleOnOff.position(10, 10);
  toggleOnOff.mousePressed(function(){
    if (theNoise.started == true) {theNoise.stop();} else {theNoise.start();}    
  })
  chooseNoise = createSelect("Noise selcter").position(60, 10);
  chooseNoise.option("white");
  chooseNoise.option("pink");
  chooseNoise.option("brown");
  chooseNoise.changed(function (){
    theNoise.setType(chooseNoise.value())
  });
  
  

  setVolume = createSlider(0, 1, 0, 0).position(120, 10);
  setVolume.changed(function(){
    theNoise.amp(setVolume.value(), 0.01)
  });
  //playButton = createButton("play").position(10, 10).mousePressed(() =>{theNoise.start();})
  //stopButton = createButton("stop").position(10, 30).mousePressed(()=> {theNoise.stop();});

}
